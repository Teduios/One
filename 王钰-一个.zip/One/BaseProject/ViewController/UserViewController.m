//
//  UserViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "UserViewController.h"
#import "LoginViewController.h"
#import "UserInfoViewController.h"
#import "SettingTableViewController.h"
#import "AboutViewController.h"
@interface UserViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)NSUserDefaults *userDefault;
@end
@interface UserCell : UITableViewCell
@property(nonatomic,strong)UIImageView *iconView;
@property(nonatomic,strong)UILabel *label;
@end
@implementation UserCell
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.accessoryType = 1;
    }
    return self;
}
- (UIImageView *)iconView {
    if(_iconView == nil) {
        _iconView = [[UIImageView alloc] init];
        _iconView.layer.cornerRadius = 30/2;
        _iconView.layer.masksToBounds = YES;
        [self.contentView addSubview:_iconView];
        [_iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(30, 30));
            
        }];
    }
    return _iconView;
}
- (UILabel *)label {
    if(_label == nil) {
        _label = [[UILabel alloc] init];
        [self.contentView addSubview:_label];
        [_label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(self.iconView.mas_right).mas_equalTo(10);
        }];
    }
    return _label;
}

@end

@implementation UserViewController
-(NSUserDefaults *)userDefault{
    if (!_userDefault) {
        //以standard开头， 单例模式
        _userDefault=[NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = NO;

   
}
//授权成功或取消授权后对用户界面进行刷新，获取用户信息。
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //[self.navigationController setNavigationBarHidden:NO];
     self.navigationController.navigationBar.hidden = NO;
       [self.tableView reloadData];
}

- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[UserCell class] forCellReuseIdentifier:@"Cell"];
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _tableView;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UserCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    //判断是否已经登录
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    path = [path stringByAppendingPathComponent:@"archivingFile"];
    
    if (indexPath.row == 0) {
        //如果已经登录 则显示用户头像及信息
        if ([self.userDefault stringForKey:@"userName"]) {
            [cell.iconView setImageWithURL:[NSURL URLWithString:[self.userDefault stringForKey:@"iconURL"]]];
            cell.label.text = [self.userDefault stringForKey:@"userName"];
        }else if(![self.userDefault stringForKey:@"userName"]){
            //未登录则显示立即登录
            [cell.iconView setImage:[UIImage imageNamed:@"p_notLogin"]];
            cell.label.text = @"立即登录";
        }
    }else if(indexPath.row == 1){
        [cell.iconView setImage:[UIImage imageNamed:@"setting"]];
        cell.label.text = @"设置";
    }else{
        [cell.iconView setImage:[UIImage imageNamed:@"copyright"]];
        cell.label.text = @"关于";
    }
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 135/2;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 0) {
        //如果已经登录 则跳转到个人详情页
        if([self.userDefault stringForKey:@"userName"]){
            UserInfoViewController *vc = [UserInfoViewController new];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }else{//没登陆则跳转到登录页面
            LoginViewController *vc = [LoginViewController new];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
    }else if(indexPath.row ==1){
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SettingTableViewController *vc =[storyBoard instantiateViewControllerWithIdentifier:@"Setting"];
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        AboutViewController *vc = [storyBoard instantiateViewControllerWithIdentifier:@"About"];
        
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}

@end
