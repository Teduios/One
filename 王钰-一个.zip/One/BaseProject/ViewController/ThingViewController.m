//
//  ThingViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ThingViewController.h"
#import "ThingViewModel.h"
#import "Factory.h"

@interface ThingViewController ()
@property(nonatomic,strong)ThingViewModel *thingVM;

@end

@implementation ThingViewController
- (ThingViewModel *)thingVM {
    if(_thingVM == nil) {
        _thingVM = [[ThingViewModel alloc] init];
    }
    return _thingVM;
}
- (UIScrollView *)scrollView {
    if(_scrollView == nil) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-64-49)];
        [_scrollView setContentSize:CGSizeMake(0, 1000)];
        [self.view addSubview:_scrollView];
    }
    return _scrollView;
}

- (UILabel *)dateLB {
    if(_dateLB == nil) {
        _dateLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_dateLB];
        [_dateLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(15);
        }];
        _dateLB.font = [UIFont systemFontOfSize:13];
    }
    return _dateLB;
}

- (UIImageView *)thingIV {
    if(_thingIV == nil) {
        _thingIV = [[UIImageView alloc] init];
        [self.scrollView addSubview:_thingIV];
        [_thingIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.dateLB.mas_bottom).mas_equalTo(15);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.width.height.mas_equalTo(kWindowW-20);
        }];
    }
    return _thingIV;
}

- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.thingIV.mas_bottom).mas_equalTo(20);
            make.leftMargin.mas_equalTo(self.dateLB);
        }];
        _titleLB.font = [UIFont boldSystemFontOfSize:17];
    }
    return _titleLB;
}

- (UILabel *)introLB {
    if(_introLB == nil) {
        _introLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_introLB];
        [_introLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.dateLB);
            make.top.mas_equalTo(self.titleLB.mas_bottom).mas_equalTo(20);
            make.bottom.mas_equalTo(-10);
            make.right.mas_equalTo(-10);
        }];
        
        _introLB.numberOfLines = 0;
    }
    return _introLB;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addShareItemToVC:self];
    [self.thingVM getDataFromNetCompleteHandle:^(NSError *error) {
        
        [self loadData];
    }];
}
-(void)loadData{
    NSMutableParagraphStyle *style = [NSMutableParagraphStyle new];
    style.lineSpacing = 8;
    
    NSDictionary *attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:15], NSParagraphStyleAttributeName:style};
    
    self.dateLB.text = [self.thingVM dateForThing];
    [self.thingIV setImageWithURL:[self.thingVM imageForThing]];
    self.titleLB.text = [self.thingVM titleForThing];
    self.introLB.attributedText = [[NSAttributedString alloc]initWithString:[self.thingVM introForThing] attributes:attribute];
    self.leftRecognizer.enabled = YES;
    self.rightRecognizer.enabled = YES;
    self.returnStr = [NSString stringWithFormat:@"%@。%@%@",[self.thingVM titleForThing],[self.thingVM introForThing],[self.thingVM strWu]];
    self.returnImg = [self.thingVM strBu];
    self.returnURL = [self.thingVM strWu];
    self.returnTitle = [self.thingVM titleForThing];

}

#pragma mark - 手势刷新
//手势触发操作
-(void)handleSwipeFrom:(UISwipeGestureRecognizer *)recognizer{
    
    if(recognizer.direction==UISwipeGestureRecognizerDirectionLeft) {
        
        [self.thingVM nextPageDataCompletionHandle:^(NSError *error) {
            //添加翻页动画
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlUp  animations:^{
                [self loadData];
        } completion:nil];
            
        }];
    }
    if (recognizer.direction==UISwipeGestureRecognizerDirectionRight)
    {
        [self.thingVM lastPageDataCompletionHandle:^(NSError *error) {
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlDown animations:^{
                
                [self loadData];
            } completion:nil];
            
        }];
    }
}



@end
