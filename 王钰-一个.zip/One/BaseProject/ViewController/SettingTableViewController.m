//
//  SettingTableViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SettingTableViewController.h"
#import "UMSocial.h"
@interface SettingTableViewController ()
@property(nonatomic,strong)UIButton *backBtn;
@property(nonatomic,strong)NSUserDefaults *userDefault;
@end

@implementation SettingTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设置";
    self.backBtn.enabled = YES;
    
}
-(NSUserDefaults *)userDefault{
    if (!_userDefault) {
        //以standard开头， 单例模式
        _userDefault=[NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}
- (UIButton *)backBtn {
    if(_backBtn == nil) {
        _backBtn =  [UIButton buttonWithType:UIButtonTypeCustom];
        [_backBtn setFrame:CGRectMake(0, 0, 10, 20)];
        [_backBtn setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithCustomView:_backBtn];
        [self.navigationItem setLeftBarButtonItem:item];
        [_backBtn bk_addEventHandler:^(id sender) {
            [self.navigationController popViewControllerAnimated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _backBtn;
}

#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    //不能设置为0，否则无效
    return 0.1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section==3) {
        return 0;
    }
    return 30;
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section==0) {
        return @"浏览设置";
    }else if(section ==1){
        return @"缓存设置";
    }else if(section==2){
        return @"更多";
    }
    return @"";
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSInteger section = [indexPath section];
    if (section == 3) {
        //取消微博授权
        [[UMSocialDataService defaultDataService] requestUnOauthWithType:UMShareToSina  completion:^(UMSocialResponseEntity *response){
            NSLog(@"response is %@",response);
        }];
        NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        path = [path stringByAppendingPathComponent:@"archivingFile"];
        //如果存在用户数据 则删除
        if ([self.userDefault stringForKey:@"userName"]) {
            [self.userDefault removeObjectForKey:@"userName"];
            [self.userDefault removeObjectForKey:@"iconURL"];
            
        }

         [self.navigationController popViewControllerAnimated:YES];
    }
    
   }


@end
