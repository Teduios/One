//
//  ArticleViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleViewController.h"
#import "ArticleViewModel.h"
#import "Factory.h"

@interface ArticleViewController()

@property (nonatomic,strong) ArticleViewModel *articleVM;
@end

@implementation ArticleViewController

- (ArticleViewModel *)articleVM {
    if(_articleVM == nil) {
        _articleVM = [[ArticleViewModel alloc] init];
    }
    return _articleVM;
}

- (UITextView *)contentTV {
    if(_contentTV == nil) {
        _contentTV = [[UITextView alloc] init];
        // _contentTV.backgroundColor = [UIColor lightGrayColor];
        [self.view addSubview:_contentTV];
        //UITextView为UIScrollView的子类，但是sv添加到view中不会减去tabbar高度 tv则会减去tabbar高度
        [_contentTV mas_makeConstraints:^(MASConstraintMaker *make) {
            //            make.top.mas_equalTo(self.view);
            //            make.bottom.mas_equalTo(self.view);
            make.edges.mas_equalTo(0);
            //            make.left.right.mas_equalTo(0);
        }];
        _contentTV.editable = NO;
        //设置文字离屏幕边距
        _contentTV.textContainerInset = UIEdgeInsetsMake(130, 10, 260, 10);
    }
    return _contentTV;
}
- (UILabel *)dateLB {
    if(_dateLB == nil) {
        _dateLB = [[UILabel alloc] init];
        [self.contentTV addSubview:_dateLB];
        _dateLB.font = [UIFont systemFontOfSize:13];
        [_dateLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentTV.mas_top).mas_equalTo(15);
            make.left.mas_equalTo(14);
            make.width.mas_equalTo(100);
        }];
        
    }
    return _dateLB;
}

- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] init];
        [self.contentTV addSubview:_titleLB];
        _titleLB.font = [UIFont boldSystemFontOfSize:16];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.dateLB);
            make.top.mas_equalTo(self.dateLB.mas_bottom).mas_equalTo(15);
            make.right.mas_equalTo(self.line);
        }];
        _titleLB.numberOfLines = 0;
    }
    return _titleLB;
}

- (UILabel *)authorLB {
    if(_authorLB == nil) {
        _authorLB = [[UILabel alloc] init];
        [self.contentTV addSubview:_authorLB];
        _authorLB.font = [UIFont systemFontOfSize:13];
        [_authorLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.dateLB);
            make.top.mas_equalTo(self.titleLB.mas_bottom).mas_equalTo(3);
        }];
    }
    return _authorLB;
}

- (UILabel *)introduceLB {
    if(_introduceLB == nil) {
        _introduceLB = [[UILabel alloc] init];
        [self.contentTV addSubview:_introduceLB];
        //_introduceLB.backgroundColor = [UIColor redColor];
        _introduceLB.font = [UIFont italicSystemFontOfSize:13];
        [_introduceLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(15);
            //要相对于textInput布局 否则添加的label会在textview头部
            make.bottom.mas_equalTo(self.contentTV.textInputView.mas_bottom).mas_equalTo(-230);
            //make.bottom.mas_equalTo(self.contentTV.mas_bottom).mas_equalTo(-100);
        }];
    }
    return _introduceLB;
}
- (UIImageView *)line {
    if(_line == nil) {
        _line = [UIImageView new];
        [self.contentTV addSubview:_line];
        [_line setImage:[UIImage imageNamed:@"conClipLine"]];
        [_line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(15);
            make.bottom.mas_equalTo(self.introduceLB.mas_bottom).mas_equalTo(50);
            make.size.mas_equalTo(CGSizeMake(kWindowW-30, 1));
        }];
        
    }
    return _line;
}

- (UILabel *)authorBottomLB {
    if(_authorBottomLB == nil) {
        _authorBottomLB = [[UILabel alloc] init];
        [self.contentTV addSubview:_authorBottomLB];
        [_authorBottomLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.dateLB);
            make.top.mas_equalTo(self.line.mas_bottom).mas_equalTo(30);
        }];
    }
    return _authorBottomLB;
}

- (UILabel *)weiboLB {
    if(_weiboLB == nil) {
        _weiboLB = [[UILabel alloc] init];
        [self.contentTV addSubview:_weiboLB];
        [_weiboLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.authorBottomLB.mas_right).mas_equalTo(2);
            make.bottomMargin.mas_equalTo(self.authorBottomLB);
        }];
        _weiboLB.textColor = [UIColor lightGrayColor];
        _weiboLB.font = [UIFont systemFontOfSize:13];
    }
    return _weiboLB;
}

- (UILabel *)authorIntroLB {
    if(_authorIntroLB == nil) {
        _authorIntroLB = [[UILabel alloc] init];
        [self.contentTV addSubview:_authorIntroLB];
        [_authorIntroLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.dateLB);
            make.top.mas_equalTo(self.authorBottomLB.mas_bottom).mas_equalTo(25);
            make.rightMargin.mas_equalTo(self.line);
        }];
        _authorIntroLB.numberOfLines = 0;
        //_authorIntroLB.font = [UIFont systemFontOfSize:14];
    }
    return _authorIntroLB;
}

-(void)viewDidLoad{
    [super viewDidLoad];
    [Factory addShareItemToVC:self];
    [self.articleVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self loadData];
    }];
    
    
    
}

#pragma mark - 手势刷新

//手势触发操作
-(void)handleSwipeFrom:(UISwipeGestureRecognizer *)recognizer{
    
    if(recognizer.direction==UISwipeGestureRecognizerDirectionLeft) {
        
        [self.articleVM nextPageDataCompletionHandle:^(NSError *error) {
            //添加翻页动画
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlUp  animations:^{
                [self loadData];
                
                
            } completion:nil];
           
        }];
    }
    if (recognizer.direction==UISwipeGestureRecognizerDirectionRight)
    {
        [self.articleVM lastPageDataCompletionHandle:^(NSError *error) {
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlDown animations:^{
               
                [self loadData];
            } completion:nil];
           
        }];
    }
}
-(void)loadData{
    //翻页后将下一页跳到顶部
    [self.contentTV setContentOffset:CGPointZero];
    self.dateLB.text = [self.articleVM strContMarketTime];
    self.titleLB.text = [self.articleVM strContTitle];
    self.authorLB.text = [self.articleVM strContAuthor];
    self.introduceLB.text = [self.articleVM strContAuthorIntroduce];
    self.authorBottomLB.text = [self.articleVM strContAuthor];
    self.weiboLB.text = [self.articleVM sWbN];
    self.contentTV.hidden = NO;
    
    NSMutableParagraphStyle *style = [NSMutableParagraphStyle new];
    style.lineSpacing = 8;
    
    NSDictionary *attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:15], NSParagraphStyleAttributeName:style};
    NSString *str = [self.articleVM strContent];
    //将content离网页的换行转换
    
   NSString *content = [str stringByReplacingOccurrencesOfString:@"<br>" withString:@"\r\n"];
    
    NSString *author = [self.articleVM sAuth];
    self.authorIntroLB.attributedText = [[NSAttributedString alloc]initWithString:author attributes:attribute];
    self.contentTV.attributedText = [[NSAttributedString alloc]initWithString:content attributes:attribute];
    self.line.hidden = NO;
  
    self.leftRecognizer.enabled = YES;
    self.rightRecognizer.enabled = YES;
    self.returnStr = [NSString stringWithFormat:@"《%@》作者/%@。%@ %@",[self.articleVM strContTitle],[self.articleVM strContAuthor],[self.articleVM sGW],[self.articleVM sWebLink]];
    self.returnURL = [self.articleVM sWebLink];
    self.returnTitle = [NSString stringWithFormat:@"《%@》作者/%@",[self.articleVM strContTitle],[self.articleVM strContAuthor]];


}





@end
