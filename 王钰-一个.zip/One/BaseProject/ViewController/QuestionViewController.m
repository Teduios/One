//
//  QuestionViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionViewController.h"
#import "QuestionViewModel.h"
#import "Factory.h"

@interface QuestionViewController ()<UIScrollViewDelegate>
@property(nonatomic,strong)QuestionViewModel *quesVM;


@end

@implementation QuestionViewController
- (UILabel *)dateLB {
    if(_dateLB == nil) {
        _dateLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_dateLB];
        //_dateLB.backgroundColor = [UIColor redColor];
        [_dateLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(15);
            make.left.mas_equalTo(10);
        }];
        _dateLB.font = [UIFont systemFontOfSize:13];
    }
    return _dateLB;
}

- (UIImageView *)quesIcon {
    if(_quesIcon == nil) {
        _quesIcon = [[UIImageView alloc] init];
        [self.scrollView addSubview:_quesIcon];
        [_quesIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.dateLB.mas_bottom).mas_equalTo(20);
            make.size.mas_equalTo(CGSizeMake(40, 40));
            make.left.mas_equalTo(15);
            
        }];
    }
    return _quesIcon;
}

- (UILabel *)quesTitleLB {
    if(_quesTitleLB == nil) {
        _quesTitleLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_quesTitleLB];
        [_quesTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.quesIcon.mas_right).mas_equalTo(10);
            make.topMargin.mas_equalTo(self.quesIcon);
            make.right.mas_equalTo(self.view.mas_right).mas_equalTo(-10);
            //make.width.mas_equalTo(kWindowW-40);
        }];
        _quesTitleLB.numberOfLines = 0;
    }
    return _quesTitleLB;
}

- (UILabel *)quesContentLB {
    if(_quesContentLB == nil) {
        _quesContentLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_quesContentLB];
        [_quesContentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.dateLB);
            make.top.mas_equalTo(self.quesIcon.mas_bottom).mas_equalTo(10);
            make.rightMargin.mas_equalTo(self.quesTitleLB);
        }];
        _quesContentLB.numberOfLines = 0;
    }
    
    return _quesContentLB;
}

- (UIImageView *)line {
    if(_line == nil) {
        _line = [[UIImageView alloc] init];
        [_line setImage:[UIImage imageNamed:@"que_line"]];
        [self.scrollView addSubview:_line];
        [_line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.top.mas_equalTo(self.quesContentLB.mas_bottom).mas_equalTo(15);
            make.size.mas_equalTo(CGSizeMake(kWindowW-20, 1));
            
        }];
    }
    return _line;
}
- (UIImageView *)answerIcon {
    if(_answerIcon == nil) {
        _answerIcon = [[UIImageView alloc] init];
        [self.scrollView addSubview:_answerIcon];
        [_answerIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.quesIcon);
            make.size.mas_equalTo(self.quesIcon);
            make.top.mas_equalTo(self.line.mas_bottom).mas_equalTo(15);
        }];
        
    }
    return _answerIcon;
}

- (UILabel *)answerTitleLB {
    if(_answerTitleLB == nil) {
        _answerTitleLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_answerTitleLB];
        [_answerTitleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.quesTitleLB);
            make.topMargin.mas_equalTo(self.answerIcon);
            
        }];
        
    }
    return _answerTitleLB;
}

- (UILabel *)answerContentTV {
    if(_answerContentTV == nil) {
        _answerContentTV = [UILabel new];
        [self.scrollView addSubview:_answerContentTV];
       // _answerContentTV.backgroundColor = [UIColor redColor];
        [_answerContentTV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.answerIcon.mas_bottom).mas_equalTo(20);
            make.rightMargin.mas_equalTo(self.quesContentLB);
            make.bottom.mas_equalTo(self.scrollView.mas_bottom).mas_equalTo(-15);
        }];
        _answerContentTV.numberOfLines = 0;
    }
    return _answerContentTV;
}
- (UIScrollView *)scrollView {
    if(_scrollView == nil) {
        //除去导航栏状态栏 和tabbar高度
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-64-49)];
        [_scrollView setContentSize:CGSizeMake(0, 1000)];
        //_scrollView.scrollEnabled = YES;
        [self.view addSubview:_scrollView];
        // _scrollView.backgroundColor = [UIColor lightGrayColor];
        //不能用masonry设置 否则报错
        /*[_scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
         make.left.right.top.mas_equalTo(0);
         make.bottom.mas_equalTo(self.mas_bottomLayoutGuideTop).mas_equalTo(0);
         }];*/
        
        
    }
    return _scrollView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addShareItemToVC:self];
    [self.quesVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self loadData];
    }];
    
}

- (QuestionViewModel *)quesVM {
    if(_quesVM == nil) {
        _quesVM = [[QuestionViewModel alloc] init];
        
    }
    return _quesVM;
}


#pragma mark - 手势刷新

//手势触发操作
-(void)handleSwipeFrom:(UISwipeGestureRecognizer *)recognizer{
    
    if(recognizer.direction==UISwipeGestureRecognizerDirectionLeft) {
        
        [self.quesVM nextPageDataCompletionHandle:^(NSError *error) {
            //添加翻页动画
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlUp  animations:^{
                [self loadData];
                
                
            } completion:nil];
            
        }];
    }
    if (recognizer.direction==UISwipeGestureRecognizerDirectionRight)
    {
        [self.quesVM lastPageDataCompletionHandle:^(NSError *error) {
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlDown animations:^{
                
                [self loadData];
            } completion:nil];
            
        }];
    }
}
-(void)loadData{
    //翻页后将下一页跳到顶部
    [self.scrollView setContentOffset:CGPointZero];
    self.scrollView.hidden = NO;
    self.line.hidden = NO;
    //设置文字样式
    NSMutableParagraphStyle *style = [NSMutableParagraphStyle new];
    style.lineSpacing = 8;
    
    NSDictionary *attribute = @{NSFontAttributeName:[UIFont systemFontOfSize:14], NSParagraphStyleAttributeName:style};
    NSDictionary *titleAttr = @{NSFontAttributeName:[UIFont systemFontOfSize:15], NSParagraphStyleAttributeName:style};
    
    NSString *content =  [self.quesVM contentForAnwser];
    //将content离网页的换行转换
    content = [content stringByReplacingOccurrencesOfString:@"<br>" withString:@"\r\n"];
   
    NSString *questionContent =  [self.quesVM contentForQuestion];
    questionContent = [questionContent stringByReplacingOccurrencesOfString:@"<br>" withString:@"\r\n"];
    
    
    NSString *questionTitle = [self.quesVM titleForQuestion];
    
    NSString *answerTitle = [self.quesVM titleForAnswer];
    self.dateLB.text = [self.quesVM dateForQuestion];
    self.quesTitleLB.attributedText = [[NSAttributedString alloc]initWithString:questionTitle attributes:titleAttr];
    self.quesContentLB.attributedText = [[NSAttributedString alloc]initWithString:questionContent attributes:attribute];
    [self.quesIcon setImage:[UIImage imageNamed:@"que_img"]];
    [self.answerIcon setImage:[UIImage imageNamed:@"ans_img"]];
    self.answerTitleLB.attributedText = [[NSAttributedString alloc]initWithString:answerTitle attributes:titleAttr];
    self.answerContentTV.attributedText = [[NSAttributedString alloc]initWithString:content attributes:attribute];
    self.leftRecognizer.enabled = YES;
    self.rightRecognizer.enabled = YES;
    self.returnStr = [NSString stringWithFormat:@"%@%@",[self.quesVM titleForQuestion],[self.quesVM sWebLink]];
    self.returnURL = [self.quesVM sWebLink];
    self.returnTitle = [self.quesVM titleForQuestion];
    

}

@end
