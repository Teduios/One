//
//  QuestionViewController.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyViewController.h"
@interface QuestionViewController : MyViewController
@property(nonatomic,strong)UILabel *dateLB;
@property(nonatomic,strong)UIImageView *quesIcon;
@property(nonatomic,strong)UILabel *quesTitleLB;
@property(nonatomic,strong)UILabel *quesContentLB;


@property(nonatomic,strong)UIImageView *answerIcon;
@property(nonatomic,strong)UILabel *answerTitleLB;
@property(nonatomic,strong)UILabel *answerContentTV;
@property(nonatomic,strong)UIImageView *line;
@property(nonatomic,strong)UIScrollView *scrollView;



@end
