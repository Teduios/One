//
//  MyViewController.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UMSocial.h"
#import "UMSocialScreenShoter.h"
#import "UMSocialSnsService.h"
@interface MyViewController : UIViewController
@property(nonatomic,strong)NSString *returnStr;
@property(nonatomic,strong)NSURL *returnImg;
@property(nonatomic,strong)NSString *returnURL;
@property(nonatomic,strong)NSString *returnTitle;
//左手势、右手势
@property(nonatomic,strong) UISwipeGestureRecognizer *leftRecognizer;
@property(nonatomic,strong) UISwipeGestureRecognizer *rightRecognizer;
@end
