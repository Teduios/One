//
//  LoginViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LoginViewController.h"
#import "UMSocial.h"
#import "UserInfoViewController.h"
//分享按钮的间距
#define kButtonSpace (kWindowW-3*85/2)/4
@interface LoginViewController ()
@property(nonatomic,strong)NSUserDefaults *userDefault;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIColor *color = [UIColor colorWithPatternImage:[UIImage imageNamed:@"login_background"]];
    self.view.backgroundColor = color;
    self.backBtn.hidden = NO;
    //隐藏本页navigationBar
    self.navigationController.navigationBar.hidden = YES;
    //退回后隐藏backButton
    self.navigationItem.hidesBackButton = YES;
    self.logoIV.hidden = NO;
    self.sinaBtn.hidden = NO;
    self.wechatBtn.hidden = NO;
    self.qqBtn.hidden = NO;
    self.line1.hidden = NO;
    self.label.hidden = NO;
    self.line2.hidden = NO;
}
-(NSUserDefaults *)userDefault{
    if (!_userDefault) {
        //以standard开头， 单例模式
        _userDefault=[NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}
- (UIButton *)backBtn {
    if(_backBtn == nil) {
        _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.view addSubview:_backBtn];
        [_backBtn setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        [_backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.mas_topLayoutGuideBottom).mas_equalTo(20);
        }];
        [_backBtn bk_addEventHandler:^(id sender) {
            [self.navigationController popViewControllerAnimated:YES];
             self.navigationController.navigationBar.hidden = NO;
        }forControlEvents:UIControlEventTouchUpInside];
    }
    return _backBtn;
}

- (UIImageView *)logoIV {
    if(_logoIV == nil) {
        _logoIV = [[UIImageView alloc] init];
        [self.view addSubview:_logoIV];
        [_logoIV setImage:[UIImage imageNamed:@"login_logo"]];
        [_logoIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(kWindowH*0.3);
        }];
    }
    return _logoIV;
}



- (UIButton *)sinaBtn {
    if(_sinaBtn == nil) {
        _sinaBtn = [[UIButton alloc] init];
        [self.view addSubview:_sinaBtn];
        [_sinaBtn setBackgroundImage:[UIImage imageNamed:@"login_weibo"] forState:UIControlStateNormal];
        [_sinaBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.logoIV.mas_bottom).mas_equalTo(100);
            make.left.mas_equalTo(kButtonSpace);
            make.size.mas_equalTo(CGSizeMake(85/2, 85/2));
        }];
        [_sinaBtn bk_addEventHandler:^(id sender) {
            UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
            
            snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                //          获取微博用户名、uid、token等
                if (response.responseCode == UMSResponseCodeSuccess) {
                    UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
                    
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                    [self.userDefault setValue:snsAccount.userName forKey:@"userName"];
                    [self.userDefault setValue:snsAccount.iconURL forKey:@"iconURL"];
                    //同步到沙盒
                    [self.userDefault synchronize];
                    //跳转到用户信息页
//                    UserInfoViewController *vc = [UserInfoViewController new];
//                    vc.hidesBottomBarWhenPushed = YES;
//                    [self.navigationController pushViewController:vc animated:YES];
                    //跳转到个人页
                    [self.navigationController popViewControllerAnimated:YES];
                    
                }});
            [[UMSocialDataService defaultDataService] requestSnsInformation:UMShareToSina  completion:^(UMSocialResponseEntity *response){
                NSLog(@"SnsInformation is %@",response.data);
            }];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _sinaBtn;
}

- (UIButton *)wechatBtn {
    if(_wechatBtn == nil) {
        _wechatBtn = [[UIButton alloc] init];
        [self.view addSubview:_wechatBtn];
        [_wechatBtn setBackgroundImage:[UIImage imageNamed:@"login_weChat"] forState:UIControlStateNormal];
        [_wechatBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.sinaBtn);
            make.left.mas_equalTo(self.sinaBtn.mas_right).mas_equalTo(kButtonSpace);
             make.size.mas_equalTo(CGSizeMake(85/2, 85/2));
        }];
        [_wechatBtn bk_addEventHandler:^(id sender) {
            UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToWechatSession];
            
            snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary]valueForKey:UMShareToWechatSession];
                    
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                    
                }
                
            });
        } forControlEvents:UIControlEventTouchUpInside];

    }
    return _wechatBtn;
}

- (UIButton *)qqBtn {
    if(_qqBtn == nil) {
        _qqBtn = [[UIButton alloc] init];
        [self.view addSubview:_qqBtn];
        [_qqBtn setBackgroundImage:[UIImage imageNamed:@"login_qq"] forState:UIControlStateNormal];
        [_qqBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.topMargin.mas_equalTo(self.sinaBtn);
            make.left.mas_equalTo(self.wechatBtn.mas_right).mas_equalTo(kButtonSpace);
             make.size.mas_equalTo(CGSizeMake(85/2, 85/2));
        }];
        [_qqBtn bk_addEventHandler:^(id sender) {
            UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQQ];
            
            snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
                
                //          获取微博用户名、uid、token等
                
                if (response.responseCode == UMSResponseCodeSuccess) {
                    
                    UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQQ];
                    
                    NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                    
                }});
        } forControlEvents:UIControlEventTouchUpInside];

    }
    return _qqBtn;
}
- (UIImageView *)line1 {
    if(_line1 == nil) {
        _line1 = [[UIImageView alloc] init];
        [_line1 setImage:[UIImage imageNamed:@"colLine"]];
        [self.view addSubview:_line1];
        [_line1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(self.label.mas_left).mas_equalTo(-10);
          
            make.centerY.mas_equalTo(self.label);
            
        }];
    }
    return _line1;
}
- (UILabel *)label {
    if(_label == nil) {
        _label = [[UILabel alloc] init];
        [self.view addSubview:_label];
        [_label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.sinaBtn.mas_bottom).mas_equalTo(15);
            make.centerX.mas_equalTo(0);
            make.width.mas_equalTo(130);
        }];
        _label.text = @"第三方账号登录";
        _label.textAlignment = NSTextAlignmentCenter;
        _label.textColor = [UIColor scrollViewTexturedBackgroundColor];
       
    }
    return _label;
}
- (UIImageView *)line2 {
    if(_line2 == nil) {
        _line2 = [[UIImageView alloc] init];
        [_line2 setImage:[UIImage imageNamed:@"colLine"]];
        [self.view addSubview:_line2];
        [_line2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.label.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(0);
            make.centerY.mas_equalTo(self.label);
            
        }];
    }
    return _line1;
}
@end
