//
//  ArticleViewController.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "MyViewController.h"
@interface ArticleViewController : MyViewController
@property (nonatomic,strong)  UITextView *contentTV;
@property (nonatomic,strong)  UILabel *dateLB;
@property (nonatomic,strong)  UILabel *titleLB;
@property (nonatomic,strong)  UILabel *authorLB;
@property (nonatomic,strong)  UILabel *introduceLB;
@property (nonatomic,strong)  UILabel *authorBottomLB;
@property (nonatomic,strong)  UILabel *weiboLB;
@property (nonatomic,strong)  UILabel *authorIntroLB;
@property (nonatomic,strong)  UIImageView *line;
@end
