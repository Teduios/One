//
//  LoginViewController.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property(nonatomic,strong)UIImageView *logoIV;
@property(nonatomic,strong)UIButton *backBtn;
@property(nonatomic,strong)UILabel *label;
@property(nonatomic,strong)UIButton *sinaBtn;
@property(nonatomic,strong)UIButton *wechatBtn;
@property(nonatomic,strong)UIButton *qqBtn;
@property(nonatomic,strong)UIImageView *line1;
@property(nonatomic,strong)UIImageView *line2;





@end
