//
//  UserInfoViewController.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoViewController : UIViewController
@property(nonatomic,strong)UIView *bgView;
@property(nonatomic,strong)UIImageView *iconIV;
@property(nonatomic,strong)UILabel *userNameLB;
@property(nonatomic,strong)UIImageView *line;
@property(nonatomic,strong)UIButton *picBtn;
@property(nonatomic,strong)UIImageView *line1;
@property(nonatomic,strong)UIButton *articleBtn;
@property(nonatomic,strong)UIImageView *line2;
@property(nonatomic,strong)UIButton *quesBtn;
@property(nonatomic,strong)UIImageView *line3;
@property(nonatomic,strong)UIButton *thingBtn;
@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UIButton *lookBtn;
@property(nonatomic,strong)UIButton *backBtn;


@end
