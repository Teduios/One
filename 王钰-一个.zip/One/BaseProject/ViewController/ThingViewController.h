//
//  ThingViewController.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyViewController.h"
@interface ThingViewController : MyViewController
//要相对于textInput布局 否则添加的label会在textview头部
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UILabel *dateLB;
@property(nonatomic,strong)UIImageView *thingIV;
@property(nonatomic,strong)UILabel *titleLB;
@property(nonatomic,strong)UILabel *introLB;

@end
