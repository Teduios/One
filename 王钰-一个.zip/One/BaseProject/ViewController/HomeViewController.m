//
//  HomeViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeViewModel.h"

@interface HomeViewController ()

@property(nonatomic,strong)HomeViewModel *homeVM;
@end

@implementation HomeViewController
-(HomeViewModel *)homeVM{
    if (!_homeVM) {
        _homeVM = [HomeViewModel new];
    }
    return _homeVM;
}
- (UIScrollView *)scrollView {
    if(_scrollView == nil) {
        //除去导航栏状态栏 和tabbar高度
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH-64-49)];
        [_scrollView setContentSize:CGSizeMake(0, 1000)];
        [self.view addSubview:_scrollView];
        //_scrollView.backgroundColor = [UIColor lightGrayColor];
    }
    return _scrollView;
    
    
    
}
- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] initWithFrame:CGRectZero];
        [self.scrollView addSubview:_titleLB];
        // _titleLB.backgroundColor = [UIColor redColor];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.scrollView).mas_equalTo(15);
            make.left.mas_equalTo(10);
            make.height.mas_equalTo(20);
        }];
        _titleLB.font = [UIFont systemFontOfSize:14];
        
    }
    return _titleLB;
}

- (UIImageView *)imageView {
    if(_imageView == nil) {
        _imageView = [[UIImageView alloc] init];
        [self.scrollView addSubview:_imageView];
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLB.mas_bottom).mas_equalTo(15);
            make.leftMargin.mas_equalTo(self.titleLB);
            make.right.mas_equalTo(-10);
            make.width.mas_equalTo(kWindowW-20);
            make.height.mas_equalTo(kWindowW *410/600);
        }];
    }
    return _imageView;
}

- (UILabel *)authorLB {
    if(_authorLB == nil) {
        _authorLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_authorLB];
        [_authorLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.imageView);
            make.top.mas_equalTo(self.imageView.mas_bottom).mas_equalTo(10);
        }];
        //_authorLB.backgroundColor = [UIColor redColor];
        _authorLB.font = [UIFont systemFontOfSize:13];
        _authorLB.textColor = [UIColor lightGrayColor];
        _authorLB.textAlignment = NSTextAlignmentRight;
        _authorLB.numberOfLines = 0;
    }
    return _authorLB;
}

- (UILabel *)marketTimeLB {
    if(_marketTimeLB == nil) {
        _marketTimeLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_marketTimeLB];
        [_marketTimeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentIV);
            make.left.mas_equalTo(25);
            make.height.width.mas_equalTo(45);
        }];
        _marketTimeLB.textColor = kRGBColor(48, 180, 238);
        [_marketTimeLB setFont:[UIFont boldSystemFontOfSize:40]];
    }
    return _marketTimeLB;
}
- (UIImageView *)contentIV {
    if(_contentIV == nil) {
        _contentIV = [[UIImageView alloc] init];
        _contentIV.image = [UIImage imageNamed:@"contBack"];
        
        [self.scrollView addSubview:_contentIV];
        [_contentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.authorLB.mas_bottom).mas_equalTo(15);
            make.right.mas_equalTo(-20);
            make.width.mas_equalTo(412/2);
            //make.height.mas_equalTo(self.contentLB.mas_height).mas_equalTo(20);
            
        }];
    }
    return _contentIV;
}

- (UILabel *)contentLB {
    if(_contentLB == nil) {
        _contentLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_contentLB];
        [_contentLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(self.contentIV).mas_equalTo(10);
            make.bottom.right.mas_equalTo(self.contentIV).mas_equalTo(-10);
            
        }];
        _contentLB.font = [UIFont systemFontOfSize:13];
        _contentLB.textColor = [UIColor whiteColor];
        
        _contentLB.numberOfLines = 0;
    }
    return _contentLB;
}

- (UILabel *)likeLB {
    if(_likeLB == nil) {
        _likeLB = [[UILabel alloc] init];
        [self.scrollView addSubview:_likeLB];
        [_likeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.likeBtn);
            make.right.mas_equalTo(self.likeBtn);
            make.bottom.mas_equalTo(-20);
        }];
        _likeLB.textAlignment = NSTextAlignmentRight;
        _likeLB.font = [UIFont systemFontOfSize:12];
        
        
    }
    return _likeLB;
}

- (UIButton *)likeBtn {
    if(_likeBtn == nil) {
        _likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_likeBtn setBackgroundImage:[UIImage imageNamed:@"home_likeBg"] forState:UIControlStateNormal];
        //先设置按钮的Normal状态，在此处设置 selected图片无效
        [_likeBtn setImage:[UIImage imageNamed:@"home_like"] forState:UIControlStateNormal];
        [self.scrollView addSubview:_likeBtn];
        [_likeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.bottom.mas_equalTo(-20);
            make.top.mas_equalTo(self.contentLB.mas_bottom).mas_equalTo(30);
            make.right.mas_equalTo(0);
            make.width.mas_equalTo(60);
        }];
        [_likeBtn bk_addEventHandler:^(id sender) {
            //获取按钮点击后的状态 每次点击状态和原来状态相反
            _likeBtn.selected = !_likeBtn.selected;
            [_likeBtn setImage:[UIImage imageNamed:@"home_like_hl"] forState:UIControlStateSelected];
            NSInteger like = [self.homeVM strPn].integerValue+1;
            self.likeLB.text = [NSString stringWithFormat:@"%ld",like];
            
            
            
        } forControlEvents:UIControlEventTouchUpInside];
        _likeBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -30, 0, 0);
    }
    return _likeBtn;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addShareItemToVC:self];
    [self.homeVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self loadData];
    }];
    
}

#pragma mark - 手势刷新

//手势触发操作
-(void)handleSwipeFrom:(UISwipeGestureRecognizer *)recognizer{
    
    if(recognizer.direction==UISwipeGestureRecognizerDirectionLeft) {
        
        [self.homeVM nextPageDataCompletionHandle:^(NSError *error) {
            //添加翻页动画
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlUp  animations:^{
                [self loadData];
                
                
            } completion:nil];
            
        }];
    }
    if (recognizer.direction==UISwipeGestureRecognizerDirectionRight)
    {
        [self.homeVM lastPageDataCompletionHandle:^(NSError *error) {
            [UIView transitionWithView:self.view duration:1 options:UIViewAnimationOptionTransitionCurlDown animations:^{
                [self loadData];
            } completion:nil];
            
        }];
    }
}

-(void)loadData{
   
    //self.view.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin;
    self.scrollView.hidden = NO;
    [self.scrollView setContentOffset:CGPointZero];
    [self.imageView setImageWithURL:[self.homeVM strImgUrl]];
    self.titleLB.text = [self.homeVM strHpTitle];
    self.contentIV.hidden = NO;
    self.likeBtn.userInteractionEnabled = YES;
    self.authorLB.text = [self.homeVM strAuthor];
    self.marketTimeLB.text = [self.homeVM strMarketTime];
    self.contentLB.text = [self.homeVM strContent];
    self.likeLB.text = [self.homeVM strPn];
    self.leftRecognizer.enabled = YES;
    self.rightRecognizer.enabled = YES;
    self.returnStr = [NSString stringWithFormat:@"%@ %@",[self.homeVM strContent],[self.homeVM webLink]];
    self.returnImg = [self.homeVM webImageUrl];
    self.returnURL = [self.homeVM webLink];
    self.returnTitle = [self.homeVM strHpTitle];
    
    
    
}





@end
