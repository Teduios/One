//
//  HomeViewController.h
//  BaseProject
//
//  Created by apple-jd02 on 15/10/31.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Factory.h"
#import "MyViewController.h"
#import "UMSocialScreenShoter.h"
@interface HomeViewController : MyViewController
@property (nonatomic,strong) UILabel *titleLB;
@property (nonatomic,strong) UIImageView *imageView;
@property (nonatomic,strong) UILabel *authorLB;
@property (nonatomic,strong) UILabel *marketTimeLB;
@property (nonatomic,strong) UILabel *contentLB;
@property (nonatomic,strong) UILabel *likeLB;
@property (nonatomic,strong) UIButton *likeBtn;
@property (nonatomic,strong) UIImageView *contentIV;
@property (nonatomic,strong)UIScrollView *scrollView;


//@property(nonatomic,strong)NSString *returnStr;
@end
