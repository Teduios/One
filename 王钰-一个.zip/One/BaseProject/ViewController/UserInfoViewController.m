//
//  UserInfoViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "UserInfoViewController.h"
#import "HomeViewController.h"
#import "ArticleViewController.h"
#import "QuestionViewController.h"
#import "ThingViewController.h"
#define kLineSpace kWindowW/4

@interface UserInfoViewController ()
@property(nonatomic,strong)NSUserDefaults *userDefault;
@end

@implementation UserInfoViewController
-(NSUserDefaults *)userDefault{
    if (!_userDefault) {
        //以standard开头， 单例模式
        _userDefault=[NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}
- (UIButton *)backBtn {
    if(_backBtn == nil) {
        _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.bgView addSubview:_backBtn];
        [_backBtn setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        [_backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(13);
            make.top.mas_equalTo(self.mas_topLayoutGuideBottom).mas_equalTo(10);
        }];
        [_backBtn bk_addEventHandler:^(id sender) {
            [self.navigationController popViewControllerAnimated:YES];
            self.navigationController.navigationBar.hidden = NO;
        }forControlEvents:UIControlEventTouchUpInside];
    }
    return _backBtn;
}
- (UIView *)bgView {
    if(_bgView == nil) {
        _bgView = [[UIImageView alloc] init];
        _bgView.userInteractionEnabled = YES;
        [self.view addSubview:_bgView];
        UIColor *color = [UIColor colorWithPatternImage:[UIImage imageNamed:@"collectionHeadBg"]];
        [_bgView setBackgroundColor:color];
        [_bgView mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.top.right.mas_equalTo(0);
            make.height.mas_equalTo(235*kWindowH/568);
      
        }];
        
    }
    return _bgView;
}
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.bgView addSubview:_iconIV];
        _iconIV.layer.cornerRadius=135/2/2;
        _iconIV.layer.masksToBounds = YES;
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(50);
            make.size.mas_equalTo(CGSizeMake(135/2, 135/2));
            
        }];
    }
    return _iconIV;
}

- (UILabel *)userNameLB {
    if(_userNameLB == nil) {
        _userNameLB = [[UILabel alloc] initWithFrame:CGRectZero];
        _userNameLB.textColor = [UIColor whiteColor];
        //_userNameLB.backgroundColor = [UIColor redColor];
        [self.bgView addSubview:_userNameLB];
        [_userNameLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(self.iconIV.mas_bottom).mas_equalTo(10);
            make.height.mas_equalTo(20);
        }];
    }
    return _userNameLB;
}

- (UIImageView *)line {
    if(_line == nil) {
        _line = [[UIImageView alloc] init];
        [_line setImage:[UIImage imageNamed:@"topHorLine"]];
        [self.bgView addSubview:_line];
        [_line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(0);
            make.top.mas_equalTo(self.bgView.mas_bottom).mas_equalTo(-45);
            make.height.mas_equalTo(1);
        }];
        
    }
    return _line;
}

- (UIButton *)picBtn {
    if(_picBtn == nil) {
        _picBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_picBtn setTitle:@"图片" forState:UIControlStateNormal];
         _picBtn.selected = YES;
         [_picBtn setTitleColor:kRGBColor(35, 181, 238) forState:UIControlStateNormal];
               _picBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15];
        [self.bgView addSubview:_picBtn];
       
        [_picBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(23);
            make.top.mas_equalTo(self.line).mas_equalTo(15);
            make.bottom.mas_equalTo(-15);
            make.size.mas_equalTo(CGSizeMake(35, 15));
        }];
        [_picBtn bk_addEventHandler:^(id sender) {
            _picBtn.selected = YES;
            if(_picBtn.selected){
                _articleBtn.selected = NO;
                _quesBtn.selected = NO;
                _thingBtn.selected = NO;
            }
            [self.articleBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.quesBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.thingBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_picBtn setTitleColor:kRGBColor(35, 181, 238) forState:UIControlStateSelected];
        } forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _picBtn;
}

- (UIImageView *)line1 {
    if(_line1 == nil) {
        _line1 = [[UIImageView alloc] init];
        [_line1 setImage:[UIImage imageNamed:@"topVerLine"]];
        [self.bgView addSubview:_line1];
        [_line1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(kLineSpace);
            make.top.mas_equalTo(self.line.mas_bottom).mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
            
        }];
    }
    return _line1;
}

- (UIButton *)articleBtn {
    if(_articleBtn == nil) {
        _articleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_articleBtn setTitle:@"文章" forState:UIControlStateNormal];
        _articleBtn.titleLabel.textColor = [UIColor whiteColor];
        _articleBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15];
        [self.bgView addSubview:_articleBtn];
        [_articleBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.line1).mas_equalTo(23);
            make.topMargin.bottomMargin.mas_equalTo(self.picBtn);
        }];
        [_articleBtn bk_addEventHandler:^(id sender) {
            _articleBtn.selected = YES;
            if(_articleBtn.selected){
                _picBtn.selected = NO;
                _quesBtn.selected = NO;
                _thingBtn.selected = NO;
            }
            [self.picBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.quesBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.thingBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_articleBtn setTitleColor:kRGBColor(35, 181, 238) forState:UIControlStateSelected];
        } forControlEvents:UIControlEventTouchUpInside];

    }
    return _articleBtn;
}

- (UIImageView *)line2 {
    if(_line2 == nil) {
        _line2 = [[UIImageView alloc] init];
        [self.bgView addSubview:_line2];
        [_line2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(self.line.mas_bottom).mas_equalTo(5);
            make.bottom.mas_equalTo(-5);

        }];
        [_line2 setImage:[UIImage imageNamed:@"topVerLine"]];
    }
    return _line2;
}

- (UIButton *)quesBtn {
    if(_quesBtn == nil) {
        _quesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_quesBtn setTitle:@"问题" forState:UIControlStateNormal];
        _quesBtn.titleLabel.textColor = [UIColor whiteColor];
        _quesBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15];
        [self.bgView addSubview:_quesBtn];
        [_quesBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.line2).mas_equalTo(23);
            make.topMargin.bottomMargin.mas_equalTo(self.picBtn);
        }];
        [_quesBtn bk_addEventHandler:^(id sender) {
            _quesBtn.selected = YES;
            if(_quesBtn.selected){
                _articleBtn.selected = NO;
                _picBtn.selected = NO;
                _thingBtn.selected = NO;
            }
            [self.articleBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.picBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.thingBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_quesBtn setTitleColor:kRGBColor(35, 181, 238) forState:UIControlStateSelected];
        } forControlEvents:UIControlEventTouchUpInside];
        

        

    }
    return _quesBtn;
}

- (UIImageView *)line3 {
    if(_line3 == nil) {
        _line3 = [[UIImageView alloc] init];
        [_line3 setImage:[UIImage imageNamed:@"topVerLine"]];
        [self.bgView addSubview:_line3];
        [_line3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.line2).mas_equalTo(kLineSpace);
            make.top.mas_equalTo(self.line.mas_bottom).mas_equalTo(5);
            make.bottom.mas_equalTo(-5);
        }];
        
    }
    return _line3;
}

- (UIButton *)thingBtn {
    if(_thingBtn == nil) {
        _thingBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_thingBtn setTitle:@"东西" forState:UIControlStateNormal];
        _thingBtn.titleLabel.textColor = [UIColor whiteColor];
        _thingBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15];
        [self.bgView addSubview:_thingBtn];
        [_thingBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.line3).mas_equalTo(23);
            make.topMargin.bottomMargin.mas_equalTo(self.picBtn);
        }];
        [_thingBtn bk_addEventHandler:^(id sender) {
            _thingBtn.selected = YES;
            if(_thingBtn.selected){
                _articleBtn.selected = NO;
                _picBtn.selected = NO;
                _quesBtn.selected = NO;
            }
            [self.articleBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.picBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [self.quesBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [_thingBtn setTitleColor:kRGBColor(35, 181, 238) forState:UIControlStateSelected];
        } forControlEvents:UIControlEventTouchUpInside];

    }
    return _thingBtn;
}

- (UIImageView *)imageView {
    if(_imageView == nil) {
        _imageView = [[UIImageView alloc] init];
        [_imageView setImage:[UIImage imageNamed:@"noCollection"]];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        //[_imageView setBackgroundColor:[UIColor blueColor]];
        [self.view addSubview:_imageView];
        [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(self.bgView.mas_bottom).mas_equalTo(100);
            make.size.mas_equalTo(CGSizeMake(130, 90));
        }];
    }
    return _imageView;
}

- (UIButton *)lookBtn {
    if(_lookBtn == nil) {
        _lookBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _lookBtn.titleLabel.textColor = [UIColor blackColor];
      
        [_lookBtn setTitle:@"去看看" forState:UIControlStateNormal];
        [_lookBtn setTitleColor:kRGBColor(35, 181, 238) forState:UIControlStateNormal];
        [self.view addSubview:_lookBtn];
        [_lookBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(self.imageView.mas_bottom).mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(60, 30));
        }];
        [_lookBtn bk_addEventHandler:^(id sender) {
            if(_picBtn.selected){
                HomeViewController *vc = [HomeViewController new];
               
                [self.navigationController pushViewController:vc animated:YES];
                self.hidesBottomBarWhenPushed = NO;
            }
            if(_articleBtn.selected){
                ArticleViewController *vc = [ArticleViewController new];
                [self.navigationController pushViewController:vc animated:YES];
            }
            if(_quesBtn.selected){
                QuestionViewController *vc = [QuestionViewController new];
                [self.navigationController pushViewController:vc animated:YES];
            }
            if(_thingBtn.selected){
                ThingViewController *vc = [ThingViewController new];
                [self.navigationController pushViewController:vc animated:YES];
            }


        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _lookBtn;
    
}

-(void)loadData{
    //获取沙盒路径
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    path = [path stringByAppendingPathComponent:@"archivingFile"];
    if ([self.userDefault stringForKey:@"userName"]) {
        [self.iconIV setImageWithURL:[NSURL URLWithString:[self.userDefault stringForKey:@"iconURL"]]];
        self.userNameLB.text = [self.userDefault stringForKey:@"userName"];
    }
    
}               
- (void)viewDidLoad {
    [super viewDidLoad];
    //隐藏本页navigationBar
//    self.navigationController.navigationBar.hidden = YES;
    //退回后隐藏backButton
    self.navigationItem.hidesBackButton = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    self.backBtn.enabled = YES;
    self.iconIV.hidden = NO;
    self.bgView.hidden = NO;
    self.userNameLB.hidden = NO;
    [self loadData];
    self.line.hidden = NO;
    self.line1.hidden = NO;
    self.line2.hidden = NO;
    self.line3.hidden = NO;
    self.picBtn.enabled = YES;
    self.articleBtn.enabled = YES;
    self.quesBtn.enabled = YES;
    self.thingBtn.enabled = YES;
    self.imageView.hidden = NO;
    self.lookBtn.enabled = YES;
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //隐藏本页navigationBar
    self.navigationController.navigationBar.hidden = YES;
}

@end
