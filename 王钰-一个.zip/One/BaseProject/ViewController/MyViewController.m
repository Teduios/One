//
//  MyViewController.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MyViewController.h"

@interface MyViewController ()

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - 摇一摇截图分享
-(BOOL)canBecomeFirstResponder {
    return YES;
}
-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    //设置第一响应者
    [self becomeFirstResponder];
    
}
//在响应摇一摇动作方法内得到屏幕截图
-(void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent*)event
{
    if(motion == UIEventSubtypeMotionShake)
    {
        //下面使用应用类型截屏，如果是cocos2d游戏或者其他类型，使用相应的截屏对象
        UIImage *image = [[UMSocialScreenShoterDefault screenShoter] getScreenShot];
        
        [UMSocialSnsService presentSnsIconSheetView:self
                                             appKey:@"5632e648e0f55a4757000efa"
                                          shareText:self.returnStr
                                         shareImage:image
                                    shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToWechatTimeline,nil]
                                           delegate:self];
        [UMSocialData defaultData].extConfig.wechatSessionData.url = self.returnURL;
        [UMSocialData defaultData].extConfig.wechatSessionData.title = self.returnTitle;
        
    }
    
    NSLog(@"=======shake it off========");
}
#pragma mark - 添加手势刷新
- (UISwipeGestureRecognizer *)leftRecognizer {
    if(_leftRecognizer == nil) {
        _leftRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(handleSwipeFrom:)];
        //添加手势
        [_leftRecognizer setDirection:UISwipeGestureRecognizerDirectionLeft];
        [self.view addGestureRecognizer:_leftRecognizer];
    }
    return _leftRecognizer;
}
- (UISwipeGestureRecognizer *)rightRecognizer {
    if(_rightRecognizer == nil) {
        _rightRecognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(handleSwipeFrom:)];
        //添加手势
        
        [_rightRecognizer setDirection:UISwipeGestureRecognizerDirectionRight];
        [self.view addGestureRecognizer:_rightRecognizer];
    }
    return _rightRecognizer;
}
-(void)handleSwipeFrom:(UISwipeGestureRecognizer *)recognizer{
}
@end
