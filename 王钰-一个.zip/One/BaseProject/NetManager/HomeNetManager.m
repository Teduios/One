//
//  HomeNetManager.m
//  BaseProject
//
//  Created by apple-jd02 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomeNetManager.h"

@implementation HomeNetManager
//http://rest.wufazhuce.com/OneForWeb/one/getHp_N?strDate=2015-10-28&strRow=1
+(id)getHomeWithDate:(NSString *)date Row:(NSInteger)row completionHandle:(void (^)(id, NSError *))completionHandle{

    NSString *path = [NSString stringWithFormat:@"http://rest.wufazhuce.com/OneForWeb/one/getHp_N?strDate=%@&strRow=%ld",date,row];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        //字典转模型
        completionHandle([HomeModel objectWithKeyValues:responseObj],error);
        
    }];
  
}
@end
