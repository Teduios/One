//
//  HomeNetManager.h
//  BaseProject
//
//  Created by apple-jd02 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "HomeModel.h"
@interface HomeNetManager : BaseNetManager
+(id)getHomeWithDate:(NSString *)date Row:(NSInteger)row kCompletionHandle;
@end
