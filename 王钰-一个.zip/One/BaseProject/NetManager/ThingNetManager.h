//
//  ThingNetManager.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "ThingModel.h"
@interface ThingNetManager : BaseNetManager
+(id)getThingWithDate:(NSString *)date Row:(NSInteger)row kCompletionHandle;
@end
