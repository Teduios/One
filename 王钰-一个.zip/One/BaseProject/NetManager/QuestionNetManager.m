//
//  QuestionNetManager.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionNetManager.h"
//http://rest.wufazhuce.com/OneForWeb/one/getQ_N?strDate=2015-10-28&strUi=534116&strRow=1
@implementation QuestionNetManager
+(id)getQuestionWithDate:(NSString *)date Row:(NSInteger)row completionHandle:(void (^)(id, NSError *))completionHandle{
    
    NSString *path =[NSString stringWithFormat:@"http://rest.wufazhuce.com/OneForWeb/one/getQ_N?strDate=%@&strUi=534116&strRow=%ld",date,row];
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
        completionHandle([QuestionModel objectWithKeyValues:responseObj],error);
         DDLogVerbose(@".....");
    }];
}
@end
