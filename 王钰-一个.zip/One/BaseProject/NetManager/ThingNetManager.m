//
//  ThingNetManager.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ThingNetManager.h"
//http://rest.wufazhuce.com/OneForWeb/one/o_f?strDate=2015-11-13&strRow=1
@implementation ThingNetManager
+(id)getThingWithDate:(NSString *)date Row:(NSInteger)row kCompletionHandle{
    NSString *path = [NSString stringWithFormat:@"http://rest.wufazhuce.com/OneForWeb/one/o_f?strDate=%@&strRow=%ld",date,row];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
            completionHandle([ThingModel objectWithKeyValues:responseObj],error);
    }];
    
    
    
}
@end
