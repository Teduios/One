//
//  ArticleNetManager.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "ArticleModel.h"
@interface ArticleNetManager : BaseNetManager
+(id)getArticleWithDate:(NSString *)date Row:(NSInteger)row kCompletionHandle;
@end
