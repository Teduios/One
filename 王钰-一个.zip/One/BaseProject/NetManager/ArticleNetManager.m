//
//  ArticleNetManager.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleNetManager.h"


@implementation ArticleNetManager
//http://rest.wufazhuce.com/OneForWeb/one/getC_N?strDate=2015-10-28&strRow=1&strMS=1
+(id)getArticleWithDate:(NSString *)date Row:(NSInteger)row completionHandle:(void (^)(id, NSError *))completionHandle{
    
    NSString *path =[NSString stringWithFormat:@"http://rest.wufazhuce.com/OneForWeb/one/getC_N?strDate=%@&strRow=%ld&strMS=1",date,row];
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
        completionHandle([ArticleModel objectWithKeyValues:responseObj],error);
       // DDLogVerbose(@".....");
    }];
}

@end
