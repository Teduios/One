//
//  HomeModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/10/29.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomeModel.h"

@implementation HomeModel

@end
@implementation HomeHpEntityModel

@end