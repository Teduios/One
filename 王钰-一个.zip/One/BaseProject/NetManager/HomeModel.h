//
//  HomeModel.h
//  BaseProject
//
//  Created by apple-jd02 on 15/10/29.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class HomeHpEntityModel;
@interface HomeModel : BaseModel
@property(nonatomic,strong)HomeHpEntityModel *hpEntity;
@property(nonatomic,strong)NSString *result;
@end
/*
 "strAuthor": "Holy Light&田楚炀 作品",
 "strContent": "星星发亮是为了让每一个人有一天都能找到属于自己的星星。 from 《小王子》",
 "strDayDiffer": "",
 "strHpId": "1136",
 "strHpTitle": "VOL.1117",
 "strLastUpdateDate": "2015-10-22 16:44:44",
 "strMarketTime": "2015-10-29",
 "strOriginalImgUrl": "http://pic.yupoo.com/hanapp/F2T98bny/gA5ra.jpg",
 "strPn": "23168",
 "strThumbnailUrl": "http://pic.yupoo.com/hanapp/F2T98bny/gA5ra.jpg",
 "sWebLk": "http://m.wufazhuce.com/one/2015-10-29",
 "wImgUrl": "http://211.152.49.184:9000/upload/onephoto/f1445503484043.jpg"
 */
@interface HomeHpEntityModel : BaseModel
@property (nonatomic, strong) NSString *strContent;
@property (nonatomic, strong) NSString *strThumbnailUrl;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) NSString *strOriginalImgUrl;
@property (nonatomic, strong) NSString *strHpId;
@property (nonatomic, strong) NSString *sWebLk;
@property (nonatomic, strong) NSString *wImgUrl;
@property (nonatomic, strong) NSString *strPn;
@property (nonatomic, strong) NSString *strDayDiffer;
@property (nonatomic, strong) NSString *strHpTitle;
@property (nonatomic, strong) NSString *strAuthor;
@property (nonatomic, strong) NSString *strMarketTime;
@end