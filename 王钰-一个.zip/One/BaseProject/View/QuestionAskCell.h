//
//  QuestionAskCell.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuestionAskCell : UITableViewCell
@property(nonatomic,strong)UILabel *dateLB;
@property(nonatomic,strong)UIImageView *iconView;
@property(nonatomic,strong)UILabel *titleLB;
@property(nonatomic,strong)UILabel *askLB;


@end
