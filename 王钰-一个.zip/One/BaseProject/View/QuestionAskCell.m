//
//  QuestionAskCell.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionAskCell.h"

@implementation QuestionAskCell
- (UILabel *)dateLB {
    if(_dateLB == nil) {
        _dateLB = [[UILabel alloc] init];
        [self.contentView addSubview:_dateLB];
        [_dateLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
        }];
        _dateLB.font = [UIFont systemFontOfSize:13];
    }
    return _dateLB;
}

- (UIImageView *)iconView {
    if(_iconView == nil) {
        _iconView = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconView];
        [_iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(15);
            make.top.mas_equalTo(self.dateLB.mas_bottom).mas_equalTo(20);
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        [_iconView setImage:[UIImage imageNamed:@"que_img"]];
    }
    return _iconView;
}

- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconView.mas_right).mas_equalTo(10);
            make.topMargin.mas_equalTo(self.iconView);
            make.right.mas_equalTo(-10);
        }];
        _titleLB.numberOfLines = 0;
    }
    return _titleLB;
}

- (UILabel *)askLB {
    if(_askLB == nil) {
        _askLB = [[UILabel alloc] init];
        [self.contentView addSubview:_askLB];
        [_askLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.mas_equalTo(self.dateLB);
            make.top.mas_equalTo(self.titleLB.mas_bottom).mas_equalTo(20);
            make.right.mas_equalTo(-10);
        }];
        _askLB.numberOfLines = 0;
        _askLB.font = [UIFont systemFontOfSize:14];
    }
    return _askLB;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
