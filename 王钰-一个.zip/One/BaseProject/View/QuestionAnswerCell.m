//
//  QuestionAnswerCell.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionAnswerCell.h"

@implementation QuestionAnswerCell
- (UIImageView *)iconView {
    if(_iconView == nil) {
        _iconView = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconView];
        [_iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(15);
            make.top.mas_equalTo(20);
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        //[_iconView setImage:[UIImage imageNamed:@"ans_img"]];
    }
    return _iconView;
}

- (UILabel *)titleLB {
    if(_titleLB == nil) {
        _titleLB = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLB];
        [_titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iconView.mas_right).mas_equalTo(10);
            make.topMargin.mas_equalTo(self.iconView);
            make.right.mas_equalTo(-10);
        }];
        _titleLB.numberOfLines = 0;
    }
    return _titleLB;
}

- (UILabel *)answerLB {
    if(_answerLB == nil) {
        _answerLB = [[UILabel alloc] init];
        [self.contentView addSubview:_answerLB];
        [_answerLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.iconView.mas_bottom).mas_equalTo(20);
            make.right.mas_equalTo(-10);
        }];
        _answerLB.numberOfLines = 0;
        _answerLB.font = [UIFont systemFontOfSize:14];
    }
    return _answerLB;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
