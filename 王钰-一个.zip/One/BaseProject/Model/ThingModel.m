//
//  ThingModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ThingModel.h"

@implementation ThingModel

@end
@implementation ThingEntTgModel

@end