//
//  ThingModel.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class ThingEntTgModel;
@interface ThingModel : BaseModel
@property (nonatomic, strong) ThingEntTgModel *entTg;
@property (nonatomic, strong) NSString *rs;
@end
@interface ThingEntTgModel : BaseModel
@property (nonatomic, strong) NSString *strTt;
@property (nonatomic, strong) NSString *strId;
@property (nonatomic, strong) NSString *strTm;
@property (nonatomic, strong) NSString *strPn;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) NSString *strBu;
@property (nonatomic, strong) NSString *strWu;
@property (nonatomic, strong) NSString *strTc;
@end