//
//  QuestionModel.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class QuestionAdEntityModel,QuestionAdEntityEntQNCmtModel;
@interface QuestionModel : BaseModel
@property (nonatomic, strong) QuestionAdEntityModel *questionAdEntity;
@property (nonatomic, strong) NSString *result;
@end
@interface QuestionAdEntityModel : BaseModel
@property (nonatomic, strong) NSString *strQuestionContent;
@property (nonatomic, strong) NSString *strQuestionMarketTime;
@property (nonatomic, strong) NSString *strQuestionId;
@property (nonatomic, strong) NSString *sEditor;
@property (nonatomic, strong) NSString *strPraiseNumber;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) QuestionAdEntityEntQNCmtModel *entQNCmt;
@property (nonatomic, strong) NSString *sWebLk;
@property (nonatomic, strong) NSString *strDayDiffer;
@property (nonatomic, strong) NSString *strAnswerTitle;
@property (nonatomic, strong) NSString *strAnswerContent;
@property (nonatomic, strong) NSString *strQuestionTitle;
@end
@interface QuestionAdEntityEntQNCmtModel : BaseModel
@property (nonatomic, strong) NSString *strId;
@property (nonatomic, strong) NSString *strCnt;
@property (nonatomic, strong) NSString *strD;
@property (nonatomic, strong) NSString *upFg;
@property (nonatomic, strong) NSString *pNum;
@end