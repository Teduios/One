//
//  ArticleModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleModel.h"
@implementation ArticleModel

@end
@implementation ArticleContentEntityModel

@end