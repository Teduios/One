//
//  QuestionModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionModel.h"

@implementation QuestionModel

@end
@implementation QuestionAdEntityModel


@end
@implementation QuestionAdEntityEntQNCmtModel



@end