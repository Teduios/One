//
//  ArticleModel.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class ArticleContentEntityModel;
@interface ArticleModel : BaseModel
@property (nonatomic, strong) ArticleContentEntityModel *contentEntity;
@property (nonatomic, strong) NSString *result;
@end

@interface ArticleContentEntityModel: BaseModel
@property (nonatomic, strong) NSString *strContent;
@property (nonatomic, strong) NSString *sRdNum;
@property (nonatomic, strong) NSString *strContentId;
@property (nonatomic, strong) NSString *subTitle;
@property (nonatomic, strong) NSString *strContDayDiffer;
@property (nonatomic, strong) NSString *sAuth;
@property (nonatomic, strong) NSString *sGW;
@property (nonatomic, strong) NSString *strLastUpdateDate;
@property (nonatomic, strong) NSString *strPraiseNumber;
@property (nonatomic, strong) NSString *sWebLk;
@property (nonatomic, strong) NSString *wImgUrl;
@property (nonatomic, strong) NSString *strContAuthorIntroduce;
@property (nonatomic, strong) NSString *strContTitle;
@property (nonatomic, strong) NSString *sWbN;
@property (nonatomic, strong) NSString *strContAuthor;
@property (nonatomic, strong) NSString *strContMarketTime;

@end 



