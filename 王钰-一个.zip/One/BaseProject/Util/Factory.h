//
//  Factory.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Factory : NSObject
/** 向某个控制器上，添加菜单按钮 */
+ (void)addShareItemToVC:(UIViewController *)vc;
//接收返回数据
@property(nonatomic,strong)NSString *returnStr;
-(void)showReturnMesssage:(NSString *)str;


@end
