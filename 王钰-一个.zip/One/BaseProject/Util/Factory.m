//
//  Factory.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "Factory.h"
#import "UMSocial.h"
#import "MyViewController.h"
@interface Factory()

@end
@implementation Factory
-(void)showReturnMesssage:(NSString *)str{
    self.returnStr = str;
}
- (NSString *)returnStr {
    if(_returnStr == nil) {
        _returnStr = [[NSString alloc] init];
    }
    return _returnStr;
}

+(void)addShareItemToVC:(MyViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"shareBtn"] forState:UIControlStateNormal];
    btn.frame = CGRectMake(0, 0, 20, 6);
    
    [btn bk_addEventHandler:^(id sender) {
        
        [UMSocialSnsService presentSnsIconSheetView:vc
                                             appKey:@"5632e648e0f55a4757000efa"
                                          shareText:vc.returnStr
                                         shareImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:vc.returnImg]]
                                    shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToWechatTimeline,nil]
                                           delegate:vc];
        [UMSocialData defaultData].extConfig.wechatSessionData.url = vc.returnURL;
        [UMSocialData defaultData].extConfig.wechatSessionData.title = vc.returnTitle;
        
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithCustomView:btn];
    vc.navigationItem.rightBarButtonItem = rightItem;
    
}
@end
