//
//  ArticleViewModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ArticleViewModel.h"
#import "ArticleNetManager.h"
@implementation ArticleViewModel
-(ArticleContentEntityModel *)model{
    if (!_model) {
        _model = [ArticleContentEntityModel new];
    }
    return _model;
}
-(NSString *)date{
    NSDate *nowDate = [NSDate date];
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.dateFormat = @"yyyy-MM-dd";
    _date = [formatter stringFromDate:nowDate];
    return _date;
}
-(ArticleContentEntityModel *)contentEntityModel{
    return self.model;
    
}
-(NSInteger)row{
    if (!_row) {
        _row = 1;
    }
    return _row;
    
}
-(NSInteger)maxRow{
    return 10;
}
-(NSString *)strContMarketTime{
     //return [self hpEntityModel].strHpTitle;
    return [self contentEntityModel].strContMarketTime;
}
-(NSString *)strContTitle{
    return [self contentEntityModel].strContTitle;
}
-(NSString *)strContAuthor{
    return [self contentEntityModel].strContAuthor;
}
-(NSString *)strContent{
    return [self contentEntityModel].strContent;
}
-(NSString *)strContAuthorIntroduce{
    return [self contentEntityModel].strContAuthorIntroduce;
}
-(NSString *)sWbN{
    return [self contentEntityModel].sWbN;
}
-(NSString *)sAuth{
    return [self contentEntityModel].sAuth;
}
-(NSURL *)wImgUrl{
    NSURL *url = [NSURL URLWithString:[self contentEntityModel].wImgUrl];
    
    return url;
}
-(NSString *)sGW{
    return [self contentEntityModel].sGW;
}
-(NSString *)sWebLink{
    return [self contentEntityModel].sWebLk;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    
    self.dataTask = [ArticleNetManager getArticleWithDate:self.date Row:self.row completionHandle:^(ArticleModel *model, NSError *error) {
        if (!_row) {
            self.model = nil;
        }
        self.model = model.contentEntity;
        completionHandle(error);
        DDLogVerbose(@"....");
    }];

}
//上一页
-(void)lastPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row==1) {
         //[self getDataFromNetCompleteHandle:completionHandle];
    }else{
        _row -= 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
   
}
//下一页
-(void)nextPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row == self.maxRow) {
//        NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:@{@"NSLocalizedDescriptionKey":@"没有更多内容"}];
//        completionHandle(error);

        //[self getDataFromNetCompleteHandle:completionHandle];
    }else{
        _row += 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
    
    
}
@end
