//
//  QuestionViewModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "QuestionViewModel.h"

@implementation QuestionViewModel
-(NSString *)date{
    NSDate *nowDate = [NSDate date];
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.dateFormat = @"yyyy-MM-dd";
    _date = [formatter stringFromDate:nowDate];
    return _date;
}
-(QuestionAdEntityModel *)questionAdEntityModel{
    return self.model;
    
}
-(NSInteger)row{
    if (!_row) {
        _row = 1;
    }
    return _row;
}
-(NSInteger)maxRow{
    return 10;
}
- (QuestionAdEntityModel *)model {
    if(_model == nil) {
        _model = [[QuestionAdEntityModel alloc] init];
    }
    return _model;
}
-(NSString *)dateForQuestion{
    return [self questionAdEntityModel].strQuestionMarketTime;
}
-(NSString *)titleForQuestion{
    return [self questionAdEntityModel].strQuestionTitle;
}
-(NSString *)contentForQuestion{
    return [self questionAdEntityModel].strQuestionContent;
}
-(NSString *)titleForAnswer{
    return [self questionAdEntityModel].strAnswerTitle;
}
-(NSString *)contentForAnwser{
    return [self questionAdEntityModel].strAnswerContent;
}
-(NSString *)sWebLink{
    return [self questionAdEntityModel].sWebLk;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [QuestionNetManager getQuestionWithDate:self.date Row:self.row completionHandle:^(QuestionModel *model, NSError *error) {
        if (!_row) {
            self.model = nil;
        }
        self.model = model.questionAdEntity;
        completionHandle(error);
        DDLogVerbose(@"...");
    }];
}
//上一页
-(void)lastPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row==1) {
        //[self getDataFromNetCompleteHandle:completionHandle];
    }else{
        _row -= 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
    
}
//下一页
-(void)nextPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row == self.maxRow) {
       
    }else{
        _row += 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
    
    
}
@end
