//
//  QuestionViewModel.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "QuestionModel.h"
#import "QuestionNetManager.h"
@interface QuestionViewModel : BaseViewModel
@property(nonatomic,strong)NSString *date;
@property(nonatomic)NSInteger row;
@property(nonatomic) NSInteger maxRow;
@property(nonatomic,strong)QuestionAdEntityModel *model;

-(NSString *)dateForQuestion;
-(NSString *)titleForQuestion;
-(NSString *)contentForQuestion;
-(NSString *)titleForAnswer;
-(NSString *)contentForAnwser;
-(NSString *)sWebLink;


@end
