//
//  ThingViewModel.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ThingModel.h"
#import "ThingNetManager.h"
@interface ThingViewModel : BaseViewModel
@property(nonatomic,strong)NSString *date;
@property(nonatomic,assign)NSInteger row;
@property(nonatomic)NSInteger maxRow;
@property(nonatomic,strong)ThingEntTgModel *model;

-(NSString *)dateForThing;
-(NSURL *)imageForThing;
-(NSString *)titleForThing;
-(NSString *)introForThing;
-(NSString *)strWu;
-(NSURL *)strBu;


@end
