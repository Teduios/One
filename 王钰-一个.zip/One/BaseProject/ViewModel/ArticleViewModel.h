//
//  ArticleViewModel.h
//  BaseProject
//
//  Created by apple-jd02 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ArticleModel.h"
@interface ArticleViewModel : BaseViewModel
@property(nonatomic,strong)NSString *date;
@property(nonatomic)NSInteger row;
@property(nonatomic) NSInteger maxRow;
@property(nonatomic,strong)ArticleContentEntityModel *model;

-(NSString *)strContMarketTime;
-(NSString *)strContTitle;
-(NSString *)strContAuthor;
-(NSString *)strContent;
-(NSString *)strContAuthorIntroduce;
-(NSString *)sWbN;
-(NSString *)sAuth;
-(NSURL *)wImgUrl;
-(NSString *)sGW;
-(NSString *)sWebLink;
@end
