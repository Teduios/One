//
//  ThingViewModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ThingViewModel.h"

@implementation ThingViewModel
- (NSString *)date {
    if(_date == nil) {
        NSDate *nowDate = [NSDate date];
        NSDateFormatter *formatter = [NSDateFormatter new];
        formatter.dateFormat = @"yyyy-MM-dd";
        //formatter.dateFormat = @"MM dd,yyyy";
        _date = [formatter stringFromDate:nowDate];
        return _date;

    }
    return _date;
}

- (ThingEntTgModel *)model {
    if(_model == nil) {
        _model = [[ThingEntTgModel alloc] init];
    }
    return _model;
}
-(NSInteger)row{
    if (!_row) {
        _row = 1;
    }
    return _row;
}
-(NSInteger)maxRow{
    return 10;
}
-(ThingEntTgModel *)modelForThing{
    return self.model;
}
-(NSString *)dateForThing{
    return [self modelForThing].strTm;
    
}
-(NSString *)strWu{
    return [self modelForThing].strWu;
}
-(NSURL *)strBu{
    return [NSURL URLWithString:[self modelForThing].strBu];
}
-(NSURL *)imageForThing{
    return [NSURL URLWithString:[self modelForThing].strBu];
}
-(NSString *)titleForThing{
    return [self modelForThing].strTt;
}
-(NSString *)introForThing{
    return [self modelForThing].strTc;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [ThingNetManager getThingWithDate:self.date Row:self.row completionHandle:^(ThingModel *model, NSError *error) {
        if (!_row) {
            self.model = nil;
        }
        self.model = model.entTg; 
        completionHandle(error);
    }];
}
//上一页
-(void)lastPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row==1) {
        //[self getDataFromNetCompleteHandle:completionHandle];
    }else{
        _row -= 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
    
}
//下一页
-(void)nextPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row == self.maxRow) {
        
    }else{
        _row += 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
    
    
}
@end
