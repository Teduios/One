//
//  HomeViewModel.m
//  BaseProject
//
//  Created by apple-jd02 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HomeViewModel.h"
#import "HomeNetManager.h"
@implementation HomeViewModel


-(HomeHpEntityModel *)model{
    if (!_model) {
        _model = [HomeHpEntityModel new];
    }
    return _model;
    
}
-(NSInteger)row{
    if (!_row) {
        _row = 1;
    }
    return _row;
    
}
-(NSInteger)maxRow{
    return 10;
}
-(NSString *)date{
    if (_date==nil) {
        NSDate *nowDate = [NSDate date];
        NSDateFormatter *formatter = [NSDateFormatter new];
        formatter.dateFormat = @"yyyy-MM-dd";
        _date = [formatter stringFromDate:nowDate];
    }
   
    return _date;
}
-(HomeHpEntityModel *)hpEntityModel{
    return self.model;
}
-(NSString *)DateForDay:(NSString *)date{
    //2015-11-02
    NSRange r = NSMakeRange(8, 2);//第五个开始，长度为2
    date = [date substringWithRange:r];
    return date;
    
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    //要用self.date才能调用初始化方法
    self.dataTask = [HomeNetManager getHomeWithDate:self.date Row:self.row completionHandle:^(HomeModel *model, NSError *error) {
        if (_date == nil) {
            self.model = nil;
        }
        self.model = model.hpEntity;
        completionHandle(error);
    }];
}
//上一页
-(void)lastPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row==1) {
        //[self getDataFromNetCompleteHandle:completionHandle];
    }else{
        _row -= 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
    
}
//下一页
-(void)nextPageDataCompletionHandle:(CompletionHandle)completionHandle{
    if (_row == self.maxRow) {
        //        NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:@{@"NSLocalizedDescriptionKey":@"没有更多内容"}];
        //        completionHandle(error);
        //[self getDataFromNetCompleteHandle:completionHandle];
    }else{
        _row += 1;
        [self getDataFromNetCompleteHandle:completionHandle];
    }
    
    
}

-(NSString *)strHpTitle{
    return [self hpEntityModel].strHpTitle;
}
-(NSString *)strAuthor{
    //用&分隔作者和作品 用\n替换换行 
    NSString *author  = [self hpEntityModel].strAuthor;
    author = [author stringByReplacingOccurrencesOfString:@"&" withString:@"\r\n"];
    return author;
}
-(NSString *)strMarketTime{
    return [self DateForDay:[self hpEntityModel].strMarketTime];
    //return [self hpEntityModel].strMarketTime ;
}
-(NSString *)strContent{
    return [self hpEntityModel].strContent;
}
-(NSURL *)strImgUrl{
    return [NSURL URLWithString:[self hpEntityModel].strThumbnailUrl];
}
-(NSString *)strPn{
    return [self hpEntityModel].strPn;
}
-(NSString *)webLink{
    return [self hpEntityModel].sWebLk;
}
-(NSURL *)webImageUrl{
    return [NSURL URLWithString:[self hpEntityModel].wImgUrl];
}

@end
